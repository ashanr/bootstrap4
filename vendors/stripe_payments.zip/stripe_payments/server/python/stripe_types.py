# Types -- these represent resources from the Stripe API

# https://stripe.com/docs/api#sources
Source = dict
# https://stripe.com/docs/api#orders
Order = dict
# https://stripe.com/docs/api#service_products
Product = dict
#https://stripe.com/docs/api#charges
Charge = dict
