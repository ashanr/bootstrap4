/*


-- Dumping tables for database: `b4system`


SET FOREIGN_KEY_CHECKS=0; 


-- Dumping structure for table: `in_sysprvlg`

DROP TABLE IF EXISTS `in_sysprvlg`;
CREATE TABLE `in_sysprvlg` (
  `prvCode` int(11) NOT NULL,
  `prvName` varchar(100) NOT NULL,
  `prvStatus` int(3) NOT NULL DEFAULT '1',
  `usrPrvMnuName` varchar(100) NOT NULL,
  `usrPrvMnuName_sinhala` varchar(255) DEFAULT NULL,
  `usrPrvMnuIcon` varchar(45) DEFAULT '',
  `usrPrvMnuPath` varchar(100) NOT NULL,
  `usrPrnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`prvCode`),
  UNIQUE KEY `user_privilage_code` (`prvCode`) USING BTREE,
  UNIQUE KEY `user_privilage_code_2` (`prvCode`,`prvName`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_sysprvlg

INSERT INTO `in_sysprvlg` VALUES('100', 'System Data', '1', 'System Data', '', 'systemSettings.png', '-', '0');
INSERT INTO `in_sysprvlg` VALUES('101', 'General', '1', 'General', '', 'systemSettings.png', '-', '0');
INSERT INTO `in_sysprvlg` VALUES('103', 'View', '1', 'View', '', '-', '-', '0');
INSERT INTO `in_sysprvlg` VALUES('104', 'Settings', '1', 'Settings', '', '', '', '0');
INSERT INTO `in_sysprvlg` VALUES('110', 'Backups', '1', 'Backups', '', '', 'backups.php', '0');
INSERT INTO `in_sysprvlg` VALUES('120', 'Notifications', '1', 'Notifications', '', '', 'notifications.php', '101');
INSERT INTO `in_sysprvlg` VALUES('191', 'System Settings', '1', 'System Settings', '', 'systemSettings.png', 'settings_dashboard.php', '104');
INSERT INTO `in_sysprvlg` VALUES('192', 'User Management', '1', 'User Management', '', 'usermanege.png', 'userManegement.php', '104');
INSERT INTO `in_sysprvlg` VALUES('193', 'System Backup', '1', 'System Backup', '', '-', 'backups.php', '104');


-- Dumping structure for table: `in_system_notifications`

DROP TABLE IF EXISTS `in_system_notifications`;
CREATE TABLE `in_system_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `set_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;



-- Dumping data for table: in_system_notifications

INSERT INTO `in_system_notifications` VALUES('1', 'dfadfa', 'fdadfafd', '', '', '');
INSERT INTO `in_system_notifications` VALUES('2', 'fdadfa', 'fdafa', '', '', '');


-- Dumping structure for table: `in_usr`

DROP TABLE IF EXISTS `in_usr`;
CREATE TABLE `in_usr` (
  `usrID` int(11) NOT NULL AUTO_INCREMENT,
  `usrName` varchar(50) NOT NULL DEFAULT '',
  `usrFName` varchar(100) DEFAULT NULL,
  `usrLName` varchar(100) DEFAULT NULL,
  `usrLevel` int(11) NOT NULL DEFAULT '1',
  `usrPwd` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `usrRegDate` date NOT NULL DEFAULT '0000-00-00',
  `usrStatus` int(1) NOT NULL DEFAULT '1',
  `usrAddress` varchar(200) DEFAULT NULL,
  `usrEmail` varchar(150) DEFAULT NULL,
  `lstLgDate` date NOT NULL,
  `lstLgTime` time NOT NULL,
  `usrEmpNo` varchar(100) DEFAULT NULL,
  `usrNIC` varchar(20) DEFAULT NULL,
  `usrMobileNo` varchar(20) DEFAULT NULL,
  `usrWorkTelNo` varchar(20) DEFAULT NULL,
  `usrHomeTelNo` varchar(20) DEFAULT NULL,
  `userBranchID` int(11) NOT NULL,
  PRIMARY KEY (`usrID`,`usrName`),
  UNIQUE KEY `usrEmpNo` (`usrEmpNo`) USING BTREE,
  UNIQUE KEY `usrNIC` (`usrNIC`) USING BTREE,
  KEY `id` (`usrID`) USING BTREE,
  KEY `user_level` (`usrLevel`) USING BTREE,
  KEY `user_name` (`usrName`) USING BTREE,
  CONSTRAINT `in_usr_ibfk_1` FOREIGN KEY (`usrLevel`) REFERENCES `in_usrlevel` (`lvID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usr

INSERT INTO `in_usr` VALUES('81', 'admin', '', '', '188', '56e2636af1fedd1c6f89df1ea09bf1ba120f52e7', '2014-07-07', '1', '', '', '2018-07-07', '10:37:22', '99999', '999999999V', '', '', '', '76');


-- Dumping structure for table: `in_usrlevel`

DROP TABLE IF EXISTS `in_usrlevel`;
CREATE TABLE `in_usrlevel` (
  `lvID` int(11) NOT NULL AUTO_INCREMENT,
  `lvName` varchar(100) DEFAULT NULL,
  `usrLvlPrvSeq` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lvID`),
  UNIQUE KEY `usrLvlPrvSeq` (`usrLvlPrvSeq`) USING BTREE,
  UNIQUE KEY `admin_level_name` (`lvName`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrlevel

INSERT INTO `in_usrlevel` VALUES('18', 'Super User', '20');
INSERT INTO `in_usrlevel` VALUES('188', 'admin', '1');
INSERT INTO `in_usrlevel` VALUES('194', 'User', '2');


-- Dumping structure for table: `in_usrlvlpriv`

DROP TABLE IF EXISTS `in_usrlvlpriv`;
CREATE TABLE `in_usrlvlpriv` (
  `usrLvl` int(11) NOT NULL,
  `usrPrivilage` int(11) NOT NULL,
  PRIMARY KEY (`usrLvl`,`usrPrivilage`),
  UNIQUE KEY `usrLvl` (`usrLvl`,`usrPrivilage`) USING BTREE,
  KEY `usrPrivilage` (`usrPrivilage`) USING BTREE,
  CONSTRAINT `in_usrlvlpriv_ibfk_1` FOREIGN KEY (`usrLvl`) REFERENCES `in_usrlevel` (`lvID`) ON UPDATE CASCADE,
  CONSTRAINT `in_usrlvlpriv_ibfk_2` FOREIGN KEY (`usrPrivilage`) REFERENCES `in_sysprvlg` (`prvCode`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrlvlpriv



-- Dumping structure for table: `in_usrprvlg`

DROP TABLE IF EXISTS `in_usrprvlg`;
CREATE TABLE `in_usrprvlg` (
  `usrID` int(11) NOT NULL,
  `usrPrvCode` int(11) NOT NULL,
  PRIMARY KEY (`usrID`,`usrPrvCode`),
  KEY `usrPrvCode` (`usrPrvCode`) USING BTREE,
  KEY `usrID` (`usrID`,`usrPrvCode`) USING BTREE,
  CONSTRAINT `in_usrprvlg_ibfk_1` FOREIGN KEY (`usrID`) REFERENCES `in_usr` (`usrID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrprvlg

INSERT INTO `in_usrprvlg` VALUES('81', '101');
INSERT INTO `in_usrprvlg` VALUES('81', '104');
INSERT INTO `in_usrprvlg` VALUES('81', '110');
INSERT INTO `in_usrprvlg` VALUES('81', '120');
INSERT INTO `in_usrprvlg` VALUES('81', '191');
INSERT INTO `in_usrprvlg` VALUES('81', '192');
INSERT INTO `in_usrprvlg` VALUES('81', '193');


SET FOREIGN_KEY_CHECKS=1; 

