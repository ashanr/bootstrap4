/*


-- Dumping tables for database: `usermanage`


SET FOREIGN_KEY_CHECKS=0; 


-- Dumping structure for table: `favourite_programs`

DROP TABLE IF EXISTS `favourite_programs`;
CREATE TABLE `favourite_programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_email` varchar(255) DEFAULT NULL COMMENT 'user email',
  `program_type` int(2) DEFAULT '0' COMMENT '1 = Movie | 2 = Tv Show | 3 = Live TV | 4 = Sports',
  `programme_code` varchar(255) DEFAULT NULL COMMENT 'IMDB CODES FOR MOVIES / TV SHOWS',
  `programme_name` varchar(255) DEFAULT NULL,
  `favourite` int(11) DEFAULT '0' COMMENT '1 = Favourite | 0= Not Favoured',
  `poster_url` varchar(255) DEFAULT NULL COMMENT 'MOVIE POSTER URLS',
  `logo_url` varchar(255) DEFAULT NULL COMMENT 'LIVETV CHANNEL LOGO URL',
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_email` (`customer_email`,`programme_code`) USING BTREE,
  KEY `programme_code` (`programme_code`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8;



-- Dumping data for table: favourite_programs

INSERT INTO `favourite_programs` VALUES('85', 'idragonmain@gmail.com', '1', 'tt6499752', 'Upgrade', '0', '1', '');
INSERT INTO `favourite_programs` VALUES('86', 'idragonmain@gmail.com', '1', 'tt1485796', 'The Greatest Showman', '1', 'https://image.tmdb.org/t/p/w780/b9CeobiihCx1uG1tpw8hXmpi7nm.jpg', '');
INSERT INTO `favourite_programs` VALUES('87', 'idragonmain@gmail.com', '1', 'tt7784604', 'Hereditary', '1', 'https://image.tmdb.org/t/p/w780/4GFPuL14eXi66V96xBWY73Y9PfR.jpg', '');
INSERT INTO `favourite_programs` VALUES('91', 'idragonmain@gmail.com', '1', 'tt4154756', 'Avengers Infinity War', '1', 'https://image.tmdb.org/t/p/w780/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg', '');
INSERT INTO `favourite_programs` VALUES('101', 'idragonmain@gmail.com', '3', '883', 'ABC US', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/abc.us.png');
INSERT INTO `favourite_programs` VALUES('104', 'idragonmain@gmail.com', '3', '200897', '5 Star Max US', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/5starmax.us.png');
INSERT INTO `favourite_programs` VALUES('105', 'idragonmain@gmail.com', '3', '100009', 'AMC US', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/amc.us.png');
INSERT INTO `favourite_programs` VALUES('110', 'idragonmain@gmail.com', '3', '204600', 'Cinemax Moremax US', '1', '', '');
INSERT INTO `favourite_programs` VALUES('111', 'idragonmain@gmail.com', '3', '200470', 'Cinemax US', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/cinemax.us.png');
INSERT INTO `favourite_programs` VALUES('112', 'idragonmain@gmail.com', '3', '6081', 'CNBC US', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/cnbc.us.png');
INSERT INTO `favourite_programs` VALUES('114', 'idragonmain@gmail.com', '3', '204163', 'Bet (east) US', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/bet.us.png');
INSERT INTO `favourite_programs` VALUES('120', 'idragonmain@gmail.com', '3', 'tt6048596', 'The Sinner', '1', '', 'https://thetvdb.com/banners/posters/5b33dbcf7bb7c.jpg');
INSERT INTO `favourite_programs` VALUES('121', 'idragonmain@gmail.com', '3', 'tt2193021', 'Arrow', '1', '', 'https://thetvdb.com/banners/posters/257655-27.jpg');
INSERT INTO `favourite_programs` VALUES('122', 'idragonmain@gmail.com', '3', '203844', 'A&E US', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/aande.us.png');
INSERT INTO `favourite_programs` VALUES('133', 'idragonmain@gmail.com', '4', '203385', 'At The Races UK', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/attheraces.uk.png');
INSERT INTO `favourite_programs` VALUES('134', 'idragonmain@gmail.com', '4', '404891', 'At The Races UK', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/attheraces.uk.png');
INSERT INTO `favourite_programs` VALUES('135', 'idragonmain@gmail.com', '4', '1104', 'beIN Sports 4 AR', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/beinsports4.qa.png');
INSERT INTO `favourite_programs` VALUES('136', 'idragonmain@gmail.com', '4', '1103', 'beIN Sports 3 AR', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/beinsports3.qa.png');
INSERT INTO `favourite_programs` VALUES('138', 'idragonmain@gmail.com', '3', '200410', 'A&E US', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/aande.us.png');
INSERT INTO `favourite_programs` VALUES('139', 'idragonmain@gmail.com', '3', 'tt3032476', 'Better Call Saul', '1', '', 'https://thetvdb.com/banners/posters/273181-3.jpg');
INSERT INTO `favourite_programs` VALUES('140', 'idragonmain@gmail.com', '4', '6024', 'beIN Sports 4 US', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/beinsports4.us.png');
INSERT INTO `favourite_programs` VALUES('141', 'idragonmain@gmail.com', '4', '1105', 'beIN Sports 5 AR', '1', '', 'https://github.com/Apollo2000/TVLogos/raw/master/beinsports5.qa.png');


-- Dumping structure for table: `in_clients`

DROP TABLE IF EXISTS `in_clients`;
CREATE TABLE `in_clients` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;



-- Dumping data for table: in_clients

INSERT INTO `in_clients` VALUES('1', 'ad', 'fdaf', 'fdaf2@fad.com', 'dfaf');
INSERT INTO `in_clients` VALUES('2', 'nishan', 'semmakuttiarachchi', 'nishans@gmail.com', '2015Live');


-- Dumping structure for table: `in_sysprvlg`

DROP TABLE IF EXISTS `in_sysprvlg`;
CREATE TABLE `in_sysprvlg` (
  `prvCode` int(11) NOT NULL,
  `prvName` varchar(100) NOT NULL,
  `prvStatus` int(3) NOT NULL DEFAULT '1',
  `usrPrvMnuName` varchar(100) NOT NULL,
  `usrPrvMnuName_sinhala` varchar(255) DEFAULT NULL,
  `usrPrvMnuIcon` varchar(45) DEFAULT '',
  `usrPrvMnuPath` varchar(100) NOT NULL,
  `usrPrnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`prvCode`),
  UNIQUE KEY `user_privilage_code` (`prvCode`) USING BTREE,
  UNIQUE KEY `user_privilage_code_2` (`prvCode`,`prvName`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_sysprvlg

INSERT INTO `in_sysprvlg` VALUES('100', 'System Data', '1', 'System Data', '', 'systemSettings.png', '-', '0');
INSERT INTO `in_sysprvlg` VALUES('101', 'General', '1', 'General', '', 'systemSettings.png', '-', '0');
INSERT INTO `in_sysprvlg` VALUES('103', 'View', '1', 'View', '', '-', '-', '0');
INSERT INTO `in_sysprvlg` VALUES('104', 'Settings', '1', 'Settings', '', '', '', '0');
INSERT INTO `in_sysprvlg` VALUES('110', 'Backups', '1', 'Backups', '', '', 'backups.php', '0');
INSERT INTO `in_sysprvlg` VALUES('111', 'User Management', '1', 'User Management', '', '', '', '0');
INSERT INTO `in_sysprvlg` VALUES('120', 'Notifications', '1', 'Notifications', '', '', 'notifications.php', '101');
INSERT INTO `in_sysprvlg` VALUES('121', 'Messages', '1', 'Messages', '', '-', 'messages.php', '101');
INSERT INTO `in_sysprvlg` VALUES('191', 'System Settings', '1', 'System Settings', '', 'systemSettings.png', 'settings_dashboard.php', '104');
INSERT INTO `in_sysprvlg` VALUES('192', 'Users', '1', 'Users', '', 'usermanege.png', 'userManegement.php', '111');
INSERT INTO `in_sysprvlg` VALUES('193', 'System Backup', '1', 'System Backup', '', '-', 'backups.php', '110');


-- Dumping structure for table: `in_system_notifications`

DROP TABLE IF EXISTS `in_system_notifications`;
CREATE TABLE `in_system_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `added_date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;



-- Dumping data for table: in_system_notifications

INSERT INTO `in_system_notifications` VALUES('30', 'fdadfafa', 'This is a test message for all users. Please update your password before 24 of this month. Those who failed to update password will get their new password reset link for account after 26 th of September.', '2018-09-19', '2018-09-25', '2018-09-17');
INSERT INTO `in_system_notifications` VALUES('31', 'test', 'test m', '2018-09-06', '2018-09-28', '2018-09-17');


-- Dumping structure for table: `in_user_mail`

DROP TABLE IF EXISTS `in_user_mail`;
CREATE TABLE `in_user_mail` (
  `message_id` int(11) NOT NULL,
  `message_title` varchar(255) DEFAULT NULL,
  `message_text` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `added_date` datetime DEFAULT NULL,
  `sender` varchar(255) DEFAULT NULL,
  `receiver` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



-- Dumping data for table: in_user_mail



-- Dumping structure for table: `in_usr`

DROP TABLE IF EXISTS `in_usr`;
CREATE TABLE `in_usr` (
  `usrID` int(11) NOT NULL AUTO_INCREMENT,
  `usrName` varchar(50) NOT NULL DEFAULT '',
  `usrFName` varchar(100) DEFAULT NULL,
  `usrLName` varchar(100) DEFAULT NULL,
  `usrLevel` int(11) NOT NULL DEFAULT '1',
  `usrPwd` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `usrRegDate` date NOT NULL DEFAULT '0000-00-00',
  `usrStatus` int(1) NOT NULL DEFAULT '1',
  `usrAddress` varchar(200) DEFAULT NULL,
  `usrEmail` varchar(150) DEFAULT NULL,
  `lstLgDate` date NOT NULL,
  `lstLgTime` time NOT NULL,
  `usrEmpNo` varchar(100) DEFAULT NULL,
  `usrNIC` varchar(20) DEFAULT NULL,
  `usrMobileNo` varchar(20) DEFAULT NULL,
  `usrWorkTelNo` varchar(20) DEFAULT NULL,
  `usrHomeTelNo` varchar(20) DEFAULT NULL,
  `userBranchID` int(11) NOT NULL,
  PRIMARY KEY (`usrID`,`usrName`),
  UNIQUE KEY `usrEmpNo` (`usrEmpNo`) USING BTREE,
  UNIQUE KEY `usrNIC` (`usrNIC`) USING BTREE,
  KEY `id` (`usrID`) USING BTREE,
  KEY `user_level` (`usrLevel`) USING BTREE,
  KEY `user_name` (`usrName`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usr

INSERT INTO `in_usr` VALUES('81', 'admin', 'Ashan', 'Rajapaksha', '188', 'd4a20bd514864b0ce9be0f36afa1deb110a6e217', '2018-07-07', '1', 'padeniya', 'idragonmain@gmail.com', '2018-07-07', '10:37:22', '99999', '999999999V', '', '', '', '76');
INSERT INTO `in_usr` VALUES('82', '', 'saman', '', '188', '75ccf6d7dfa6c1cfb5b0cd9b49af9340edbdc684', '0000-00-00', '1', '', '', '0000-00-00', '09:41:29', '', '', '', '', '', '1');
INSERT INTO `in_usr` VALUES('88', '', '', '', '2', '75ccf6d7dfa6c1cfb5b0cd9b49af9340edbdc684', '0000-00-00', '1', '', '', '0000-00-00', '05:07:59', '434', '452423432', '', '', '', '1');
INSERT INTO `in_usr` VALUES('89', '', '', '', '188', '75ccf6d7dfa6c1cfb5b0cd9b49af9340edbdc684', '0000-00-00', '1', '', '', '0000-00-00', '05:08:54', '42342', '43242', '', '', '', '1');
INSERT INTO `in_usr` VALUES('93', 'nimal', 'niml', 'prerea', '188', '36bbd52bb17a2a6bea4e87e7273e7a822cf8b6da', '0000-00-00', '1', 'fjdkfj;kal', '342424', '0000-00-00', '08:15:56', '3442', '23424', '23424', 'dksjfkalj', '', '1');


-- Dumping structure for table: `in_usrlevel`

DROP TABLE IF EXISTS `in_usrlevel`;
CREATE TABLE `in_usrlevel` (
  `lvID` int(11) NOT NULL AUTO_INCREMENT,
  `lvName` varchar(100) DEFAULT NULL,
  `usrLvlPrvSeq` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lvID`),
  UNIQUE KEY `usrLvlPrvSeq` (`usrLvlPrvSeq`) USING BTREE,
  UNIQUE KEY `admin_level_name` (`lvName`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrlevel

INSERT INTO `in_usrlevel` VALUES('18', 'Super User', '20');
INSERT INTO `in_usrlevel` VALUES('188', 'admin', '1');
INSERT INTO `in_usrlevel` VALUES('194', 'User', '2');


-- Dumping structure for table: `in_usrlvlpriv`

DROP TABLE IF EXISTS `in_usrlvlpriv`;
CREATE TABLE `in_usrlvlpriv` (
  `usrLvl` int(11) NOT NULL,
  `usrPrivilage` int(11) NOT NULL,
  PRIMARY KEY (`usrLvl`,`usrPrivilage`),
  UNIQUE KEY `usrLvl` (`usrLvl`,`usrPrivilage`) USING BTREE,
  KEY `usrPrivilage` (`usrPrivilage`) USING BTREE,
  CONSTRAINT `in_usrlvlpriv_ibfk_1` FOREIGN KEY (`usrLvl`) REFERENCES `in_usrlevel` (`lvID`) ON UPDATE CASCADE,
  CONSTRAINT `in_usrlvlpriv_ibfk_2` FOREIGN KEY (`usrPrivilage`) REFERENCES `in_sysprvlg` (`prvCode`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrlvlpriv



-- Dumping structure for table: `in_usrprvlg`

DROP TABLE IF EXISTS `in_usrprvlg`;
CREATE TABLE `in_usrprvlg` (
  `usrID` int(11) NOT NULL,
  `usrPrvCode` int(11) NOT NULL,
  PRIMARY KEY (`usrID`,`usrPrvCode`),
  KEY `usrPrvCode` (`usrPrvCode`) USING BTREE,
  KEY `usrID` (`usrID`,`usrPrvCode`) USING BTREE,
  CONSTRAINT `in_usrprvlg_ibfk_1` FOREIGN KEY (`usrID`) REFERENCES `in_usr` (`usrID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrprvlg

INSERT INTO `in_usrprvlg` VALUES('81', '100');
INSERT INTO `in_usrprvlg` VALUES('81', '101');
INSERT INTO `in_usrprvlg` VALUES('81', '103');
INSERT INTO `in_usrprvlg` VALUES('81', '104');
INSERT INTO `in_usrprvlg` VALUES('81', '110');
INSERT INTO `in_usrprvlg` VALUES('81', '111');
INSERT INTO `in_usrprvlg` VALUES('81', '120');
INSERT INTO `in_usrprvlg` VALUES('81', '121');
INSERT INTO `in_usrprvlg` VALUES('81', '191');
INSERT INTO `in_usrprvlg` VALUES('81', '192');
INSERT INTO `in_usrprvlg` VALUES('81', '193');


SET FOREIGN_KEY_CHECKS=1; 

