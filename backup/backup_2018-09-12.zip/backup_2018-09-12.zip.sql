/*


-- Dumping tables for database: `b4system`


SET FOREIGN_KEY_CHECKS=0; 


-- Dumping structure for table: `in_sysprvlg`

DROP TABLE IF EXISTS `in_sysprvlg`;
CREATE TABLE `in_sysprvlg` (
  `prvCode` int(11) NOT NULL,
  `prvName` varchar(100) NOT NULL,
  `prvStatus` int(3) NOT NULL DEFAULT '1',
  `usrPrvMnuName` varchar(100) NOT NULL,
  `usrPrvMnuName_sinhala` varchar(255) DEFAULT NULL,
  `usrPrvMnuIcon` varchar(45) DEFAULT '',
  `usrPrvMnuPath` varchar(100) NOT NULL,
  `usrPrnt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`prvCode`),
  UNIQUE KEY `user_privilage_code` (`prvCode`) USING BTREE,
  UNIQUE KEY `user_privilage_code_2` (`prvCode`,`prvName`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_sysprvlg

INSERT INTO `in_sysprvlg` VALUES('0', 'Credit Transfer', '1', 'Credit Transfer', '', '', 'credit_transfer.php', '140');
INSERT INTO `in_sysprvlg` VALUES('100', 'System Data', '1', 'System Data', '', 'systemSettings.png', '-', '0');
INSERT INTO `in_sysprvlg` VALUES('101', 'General', '1', 'General', '', 'systemSettings.png', '-', '0');
INSERT INTO `in_sysprvlg` VALUES('103', 'View', '1', 'View', '', '-', '-', '0');
INSERT INTO `in_sysprvlg` VALUES('106', 'File List', '1', 'View File List', '', 'systemSettings.png', 'img_view_file_list.php', '103');
INSERT INTO `in_sysprvlg` VALUES('112', 'Image Registrations', '1', 'Image Registrations', '', 'systemSettings.png', 'img_reg.php', '101');
INSERT INTO `in_sysprvlg` VALUES('114', 'System Settings', '1', 'System Settings', '', 'systemSettings.png', 'settings_dashboard.php', '120');
INSERT INTO `in_sysprvlg` VALUES('115', 'User Management', '1', 'User Management', '', 'usermanege.png', 'userManegement.php', '120');
INSERT INTO `in_sysprvlg` VALUES('116', 'Subject Management', '1', 'Subject Management', '', 'systemSettings.png', 'subject_management.php', '100');
INSERT INTO `in_sysprvlg` VALUES('120', 'Settings', '1', 'Settings', '', '-', '-', '0');
INSERT INTO `in_sysprvlg` VALUES('130', 'News', '1', 'News', '', '-', 'news.php', '123');
INSERT INTO `in_sysprvlg` VALUES('131', 'Technical Specification', '1', 'Technical Specification', '', '', 'vehicle_tech_spec.php', '123');
INSERT INTO `in_sysprvlg` VALUES('132', 'Home Page', '1', 'Home Page', '', '', 'web_homepg_content.php', '123');
INSERT INTO `in_sysprvlg` VALUES('133', 'System Backup', '1', 'System Backup', '', '-', 'run.php', '120');


-- Dumping structure for table: `in_usr`

DROP TABLE IF EXISTS `in_usr`;
CREATE TABLE `in_usr` (
  `usrID` int(11) NOT NULL AUTO_INCREMENT,
  `usrName` varchar(50) NOT NULL DEFAULT '',
  `usrFName` varchar(100) DEFAULT NULL,
  `usrLName` varchar(100) DEFAULT NULL,
  `usrLevel` int(11) NOT NULL DEFAULT '1',
  `usrPwd` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `usrRegDate` date NOT NULL DEFAULT '0000-00-00',
  `usrStatus` int(1) NOT NULL DEFAULT '1',
  `usrAddress` varchar(200) DEFAULT NULL,
  `usrEmail` varchar(150) DEFAULT NULL,
  `lstLgDate` date NOT NULL,
  `lstLgTime` time NOT NULL,
  `usrEmpNo` varchar(100) DEFAULT NULL,
  `usrNIC` varchar(20) DEFAULT NULL,
  `usrMobileNo` varchar(20) DEFAULT NULL,
  `usrWorkTelNo` varchar(20) DEFAULT NULL,
  `usrHomeTelNo` varchar(20) DEFAULT NULL,
  `userBranchID` int(11) NOT NULL,
  PRIMARY KEY (`usrID`,`usrName`),
  UNIQUE KEY `usrEmpNo` (`usrEmpNo`) USING BTREE,
  UNIQUE KEY `usrNIC` (`usrNIC`) USING BTREE,
  KEY `id` (`usrID`) USING BTREE,
  KEY `user_level` (`usrLevel`) USING BTREE,
  KEY `user_name` (`usrName`) USING BTREE,
  CONSTRAINT `in_usr_ibfk_1` FOREIGN KEY (`usrLevel`) REFERENCES `in_usrlevel` (`lvID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usr

INSERT INTO `in_usr` VALUES('78', 'mdcc', '-', '-', '18', '56e2636af1fedd1c6f89df1ea09bf1ba120f52e7', '2014-07-07', '1', '-', '', '2014-07-07', '10:30:59', '-', '', '', '', '', '76');
INSERT INTO `in_usr` VALUES('81', 'admin', '', '', '188', '56e2636af1fedd1c6f89df1ea09bf1ba120f52e7', '2014-07-07', '1', '', '', '2014-07-07', '10:37:22', '99999', '999999999V', '', '', '', '76');
INSERT INTO `in_usr` VALUES('97', 'Ranjith', '', '', '188', 'df1bd9b24501d25b26ddccd33111a70bb486cf30', '2015-08-13', '1', '', '', '2015-08-13', '01:34:54', '00', '123456211v', '', '', '', '1');
INSERT INTO `in_usr` VALUES('102', 'Thiwanka', '', '', '194', '2acbd0425ecc48ee18f85525b2039a995c588b7d', '2015-08-14', '1', '', '', '2015-08-14', '02:41:47', '123456123v', '123456123v', '', '', '', '1');
INSERT INTO `in_usr` VALUES('108', 'Roshan', '', '', '194', 'bc1dcbbfc185ac74d571393c3ce83a746d8c5142', '2015-08-14', '1', '', '', '2015-08-14', '02:43:46', '123', '323456123v', '', '', '', '1');
INSERT INTO `in_usr` VALUES('109', 'Gauri', '', '', '194', 'acfc34f340b9cfc4f8e50aed601834735c3c6d41', '2015-08-14', '1', '', '', '2015-08-14', '02:44:21', '12', '123654123v', '', '', '', '1');
INSERT INTO `in_usr` VALUES('111', 'saman', 'Saman', '', '194', '0837c36df900b197cfe68c51da2968ff368702f3', '2016-03-21', '1', '', '', '2016-03-21', '06:37:46', '', '954646545V', '', '', '', '1');


-- Dumping structure for table: `in_usrlevel`

DROP TABLE IF EXISTS `in_usrlevel`;
CREATE TABLE `in_usrlevel` (
  `lvID` int(11) NOT NULL AUTO_INCREMENT,
  `lvName` varchar(100) DEFAULT NULL,
  `usrLvlPrvSeq` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lvID`),
  UNIQUE KEY `usrLvlPrvSeq` (`usrLvlPrvSeq`) USING BTREE,
  UNIQUE KEY `admin_level_name` (`lvName`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrlevel

INSERT INTO `in_usrlevel` VALUES('18', 'Super User', '20');
INSERT INTO `in_usrlevel` VALUES('188', 'admin', '1');
INSERT INTO `in_usrlevel` VALUES('194', 'User', '2');


-- Dumping structure for table: `in_usrlvlpriv`

DROP TABLE IF EXISTS `in_usrlvlpriv`;
CREATE TABLE `in_usrlvlpriv` (
  `usrLvl` int(11) NOT NULL,
  `usrPrivilage` int(11) NOT NULL,
  PRIMARY KEY (`usrLvl`,`usrPrivilage`),
  UNIQUE KEY `usrLvl` (`usrLvl`,`usrPrivilage`) USING BTREE,
  KEY `usrPrivilage` (`usrPrivilage`) USING BTREE,
  CONSTRAINT `in_usrlvlpriv_ibfk_1` FOREIGN KEY (`usrLvl`) REFERENCES `in_usrlevel` (`lvID`) ON UPDATE CASCADE,
  CONSTRAINT `in_usrlvlpriv_ibfk_2` FOREIGN KEY (`usrPrivilage`) REFERENCES `in_sysprvlg` (`prvCode`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrlvlpriv



-- Dumping structure for table: `in_usrprvlg`

DROP TABLE IF EXISTS `in_usrprvlg`;
CREATE TABLE `in_usrprvlg` (
  `usrID` int(11) NOT NULL,
  `usrPrvCode` int(11) NOT NULL,
  PRIMARY KEY (`usrID`,`usrPrvCode`),
  KEY `usrPrvCode` (`usrPrvCode`) USING BTREE,
  KEY `usrID` (`usrID`,`usrPrvCode`) USING BTREE,
  CONSTRAINT `in_usrprvlg_ibfk_1` FOREIGN KEY (`usrID`) REFERENCES `in_usr` (`usrID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



-- Dumping data for table: in_usrprvlg

INSERT INTO `in_usrprvlg` VALUES('78', '100');
INSERT INTO `in_usrprvlg` VALUES('78', '101');
INSERT INTO `in_usrprvlg` VALUES('78', '103');
INSERT INTO `in_usrprvlg` VALUES('78', '104');
INSERT INTO `in_usrprvlg` VALUES('78', '105');
INSERT INTO `in_usrprvlg` VALUES('78', '106');
INSERT INTO `in_usrprvlg` VALUES('78', '107');
INSERT INTO `in_usrprvlg` VALUES('78', '108');
INSERT INTO `in_usrprvlg` VALUES('78', '109');
INSERT INTO `in_usrprvlg` VALUES('78', '110');
INSERT INTO `in_usrprvlg` VALUES('78', '111');
INSERT INTO `in_usrprvlg` VALUES('78', '114');
INSERT INTO `in_usrprvlg` VALUES('78', '115');
INSERT INTO `in_usrprvlg` VALUES('78', '116');
INSERT INTO `in_usrprvlg` VALUES('78', '117');
INSERT INTO `in_usrprvlg` VALUES('78', '120');
INSERT INTO `in_usrprvlg` VALUES('78', '121');
INSERT INTO `in_usrprvlg` VALUES('78', '122');
INSERT INTO `in_usrprvlg` VALUES('78', '123');
INSERT INTO `in_usrprvlg` VALUES('78', '130');
INSERT INTO `in_usrprvlg` VALUES('78', '131');
INSERT INTO `in_usrprvlg` VALUES('78', '132');
INSERT INTO `in_usrprvlg` VALUES('78', '133');
INSERT INTO `in_usrprvlg` VALUES('81', '0');
INSERT INTO `in_usrprvlg` VALUES('81', '99');
INSERT INTO `in_usrprvlg` VALUES('81', '100');
INSERT INTO `in_usrprvlg` VALUES('81', '101');
INSERT INTO `in_usrprvlg` VALUES('81', '103');
INSERT INTO `in_usrprvlg` VALUES('81', '104');
INSERT INTO `in_usrprvlg` VALUES('81', '105');
INSERT INTO `in_usrprvlg` VALUES('81', '106');
INSERT INTO `in_usrprvlg` VALUES('81', '107');
INSERT INTO `in_usrprvlg` VALUES('81', '108');
INSERT INTO `in_usrprvlg` VALUES('81', '109');
INSERT INTO `in_usrprvlg` VALUES('81', '110');
INSERT INTO `in_usrprvlg` VALUES('81', '111');
INSERT INTO `in_usrprvlg` VALUES('81', '112');
INSERT INTO `in_usrprvlg` VALUES('81', '114');
INSERT INTO `in_usrprvlg` VALUES('81', '115');
INSERT INTO `in_usrprvlg` VALUES('81', '116');
INSERT INTO `in_usrprvlg` VALUES('81', '117');
INSERT INTO `in_usrprvlg` VALUES('81', '120');
INSERT INTO `in_usrprvlg` VALUES('81', '121');
INSERT INTO `in_usrprvlg` VALUES('81', '122');
INSERT INTO `in_usrprvlg` VALUES('81', '123');
INSERT INTO `in_usrprvlg` VALUES('81', '130');
INSERT INTO `in_usrprvlg` VALUES('81', '131');
INSERT INTO `in_usrprvlg` VALUES('81', '132');
INSERT INTO `in_usrprvlg` VALUES('81', '133');
INSERT INTO `in_usrprvlg` VALUES('81', '134');
INSERT INTO `in_usrprvlg` VALUES('81', '136');
INSERT INTO `in_usrprvlg` VALUES('81', '137');
INSERT INTO `in_usrprvlg` VALUES('81', '140');
INSERT INTO `in_usrprvlg` VALUES('81', '142');
INSERT INTO `in_usrprvlg` VALUES('81', '143');
INSERT INTO `in_usrprvlg` VALUES('81', '144');
INSERT INTO `in_usrprvlg` VALUES('81', '145');
INSERT INTO `in_usrprvlg` VALUES('81', '146');
INSERT INTO `in_usrprvlg` VALUES('81', '147');
INSERT INTO `in_usrprvlg` VALUES('81', '150');
INSERT INTO `in_usrprvlg` VALUES('81', '155');
INSERT INTO `in_usrprvlg` VALUES('81', '156');
INSERT INTO `in_usrprvlg` VALUES('81', '157');
INSERT INTO `in_usrprvlg` VALUES('81', '158');
INSERT INTO `in_usrprvlg` VALUES('81', '159');
INSERT INTO `in_usrprvlg` VALUES('81', '160');
INSERT INTO `in_usrprvlg` VALUES('81', '161');
INSERT INTO `in_usrprvlg` VALUES('81', '162');
INSERT INTO `in_usrprvlg` VALUES('81', '163');
INSERT INTO `in_usrprvlg` VALUES('81', '164');
INSERT INTO `in_usrprvlg` VALUES('81', '165');
INSERT INTO `in_usrprvlg` VALUES('81', '166');
INSERT INTO `in_usrprvlg` VALUES('97', '0');
INSERT INTO `in_usrprvlg` VALUES('97', '100');
INSERT INTO `in_usrprvlg` VALUES('97', '101');
INSERT INTO `in_usrprvlg` VALUES('97', '103');
INSERT INTO `in_usrprvlg` VALUES('97', '104');
INSERT INTO `in_usrprvlg` VALUES('97', '105');
INSERT INTO `in_usrprvlg` VALUES('97', '106');
INSERT INTO `in_usrprvlg` VALUES('97', '107');
INSERT INTO `in_usrprvlg` VALUES('97', '108');
INSERT INTO `in_usrprvlg` VALUES('97', '109');
INSERT INTO `in_usrprvlg` VALUES('97', '110');
INSERT INTO `in_usrprvlg` VALUES('97', '111');
INSERT INTO `in_usrprvlg` VALUES('97', '114');
INSERT INTO `in_usrprvlg` VALUES('97', '115');
INSERT INTO `in_usrprvlg` VALUES('97', '116');
INSERT INTO `in_usrprvlg` VALUES('97', '117');
INSERT INTO `in_usrprvlg` VALUES('97', '120');
INSERT INTO `in_usrprvlg` VALUES('97', '121');
INSERT INTO `in_usrprvlg` VALUES('97', '122');
INSERT INTO `in_usrprvlg` VALUES('97', '123');
INSERT INTO `in_usrprvlg` VALUES('97', '130');
INSERT INTO `in_usrprvlg` VALUES('97', '131');
INSERT INTO `in_usrprvlg` VALUES('97', '132');
INSERT INTO `in_usrprvlg` VALUES('97', '133');
INSERT INTO `in_usrprvlg` VALUES('97', '136');
INSERT INTO `in_usrprvlg` VALUES('97', '140');
INSERT INTO `in_usrprvlg` VALUES('97', '150');
INSERT INTO `in_usrprvlg` VALUES('102', '100');
INSERT INTO `in_usrprvlg` VALUES('102', '101');
INSERT INTO `in_usrprvlg` VALUES('102', '103');
INSERT INTO `in_usrprvlg` VALUES('102', '104');
INSERT INTO `in_usrprvlg` VALUES('102', '105');
INSERT INTO `in_usrprvlg` VALUES('102', '107');
INSERT INTO `in_usrprvlg` VALUES('102', '108');
INSERT INTO `in_usrprvlg` VALUES('102', '109');
INSERT INTO `in_usrprvlg` VALUES('102', '110');
INSERT INTO `in_usrprvlg` VALUES('102', '111');
INSERT INTO `in_usrprvlg` VALUES('102', '116');
INSERT INTO `in_usrprvlg` VALUES('102', '117');
INSERT INTO `in_usrprvlg` VALUES('102', '120');
INSERT INTO `in_usrprvlg` VALUES('102', '121');
INSERT INTO `in_usrprvlg` VALUES('102', '122');
INSERT INTO `in_usrprvlg` VALUES('102', '123');
INSERT INTO `in_usrprvlg` VALUES('102', '130');
INSERT INTO `in_usrprvlg` VALUES('102', '131');
INSERT INTO `in_usrprvlg` VALUES('102', '132');
INSERT INTO `in_usrprvlg` VALUES('102', '133');
INSERT INTO `in_usrprvlg` VALUES('108', '100');
INSERT INTO `in_usrprvlg` VALUES('108', '101');
INSERT INTO `in_usrprvlg` VALUES('108', '103');
INSERT INTO `in_usrprvlg` VALUES('108', '104');
INSERT INTO `in_usrprvlg` VALUES('108', '105');
INSERT INTO `in_usrprvlg` VALUES('108', '107');
INSERT INTO `in_usrprvlg` VALUES('108', '108');
INSERT INTO `in_usrprvlg` VALUES('108', '109');
INSERT INTO `in_usrprvlg` VALUES('108', '110');
INSERT INTO `in_usrprvlg` VALUES('108', '111');
INSERT INTO `in_usrprvlg` VALUES('108', '116');
INSERT INTO `in_usrprvlg` VALUES('108', '117');
INSERT INTO `in_usrprvlg` VALUES('108', '120');
INSERT INTO `in_usrprvlg` VALUES('108', '121');
INSERT INTO `in_usrprvlg` VALUES('108', '122');
INSERT INTO `in_usrprvlg` VALUES('108', '123');
INSERT INTO `in_usrprvlg` VALUES('108', '130');
INSERT INTO `in_usrprvlg` VALUES('108', '131');
INSERT INTO `in_usrprvlg` VALUES('108', '132');
INSERT INTO `in_usrprvlg` VALUES('108', '133');
INSERT INTO `in_usrprvlg` VALUES('109', '100');
INSERT INTO `in_usrprvlg` VALUES('109', '101');
INSERT INTO `in_usrprvlg` VALUES('109', '103');
INSERT INTO `in_usrprvlg` VALUES('109', '104');
INSERT INTO `in_usrprvlg` VALUES('109', '105');
INSERT INTO `in_usrprvlg` VALUES('109', '107');
INSERT INTO `in_usrprvlg` VALUES('109', '108');
INSERT INTO `in_usrprvlg` VALUES('109', '109');
INSERT INTO `in_usrprvlg` VALUES('109', '110');
INSERT INTO `in_usrprvlg` VALUES('109', '111');
INSERT INTO `in_usrprvlg` VALUES('109', '116');
INSERT INTO `in_usrprvlg` VALUES('109', '117');
INSERT INTO `in_usrprvlg` VALUES('109', '120');
INSERT INTO `in_usrprvlg` VALUES('109', '121');
INSERT INTO `in_usrprvlg` VALUES('109', '122');
INSERT INTO `in_usrprvlg` VALUES('109', '123');
INSERT INTO `in_usrprvlg` VALUES('109', '130');
INSERT INTO `in_usrprvlg` VALUES('109', '131');
INSERT INTO `in_usrprvlg` VALUES('109', '132');
INSERT INTO `in_usrprvlg` VALUES('109', '133');
INSERT INTO `in_usrprvlg` VALUES('111', '0');
INSERT INTO `in_usrprvlg` VALUES('111', '100');
INSERT INTO `in_usrprvlg` VALUES('111', '101');
INSERT INTO `in_usrprvlg` VALUES('111', '103');
INSERT INTO `in_usrprvlg` VALUES('111', '104');
INSERT INTO `in_usrprvlg` VALUES('111', '105');
INSERT INTO `in_usrprvlg` VALUES('111', '106');
INSERT INTO `in_usrprvlg` VALUES('111', '107');
INSERT INTO `in_usrprvlg` VALUES('111', '108');
INSERT INTO `in_usrprvlg` VALUES('111', '109');
INSERT INTO `in_usrprvlg` VALUES('111', '110');
INSERT INTO `in_usrprvlg` VALUES('111', '111');
INSERT INTO `in_usrprvlg` VALUES('111', '114');
INSERT INTO `in_usrprvlg` VALUES('111', '115');
INSERT INTO `in_usrprvlg` VALUES('111', '116');
INSERT INTO `in_usrprvlg` VALUES('111', '117');
INSERT INTO `in_usrprvlg` VALUES('111', '120');
INSERT INTO `in_usrprvlg` VALUES('111', '121');
INSERT INTO `in_usrprvlg` VALUES('111', '122');
INSERT INTO `in_usrprvlg` VALUES('111', '123');
INSERT INTO `in_usrprvlg` VALUES('111', '130');
INSERT INTO `in_usrprvlg` VALUES('111', '131');
INSERT INTO `in_usrprvlg` VALUES('111', '132');
INSERT INTO `in_usrprvlg` VALUES('111', '133');
INSERT INTO `in_usrprvlg` VALUES('111', '134');
INSERT INTO `in_usrprvlg` VALUES('111', '136');
INSERT INTO `in_usrprvlg` VALUES('111', '140');
INSERT INTO `in_usrprvlg` VALUES('111', '142');
INSERT INTO `in_usrprvlg` VALUES('111', '143');
INSERT INTO `in_usrprvlg` VALUES('111', '144');
INSERT INTO `in_usrprvlg` VALUES('111', '145');
INSERT INTO `in_usrprvlg` VALUES('111', '146');
INSERT INTO `in_usrprvlg` VALUES('111', '147');
INSERT INTO `in_usrprvlg` VALUES('111', '150');
INSERT INTO `in_usrprvlg` VALUES('111', '155');
INSERT INTO `in_usrprvlg` VALUES('111', '157');
INSERT INTO `in_usrprvlg` VALUES('111', '158');
INSERT INTO `in_usrprvlg` VALUES('111', '159');
INSERT INTO `in_usrprvlg` VALUES('111', '160');
INSERT INTO `in_usrprvlg` VALUES('111', '161');
INSERT INTO `in_usrprvlg` VALUES('111', '164');
INSERT INTO `in_usrprvlg` VALUES('111', '165');


SET FOREIGN_KEY_CHECKS=1; 

